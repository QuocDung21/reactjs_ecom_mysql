// const singlebanner =  require('./assets/singlebanner.avif');
import singlebanner from  "././assets/singlebanner.avif";
// const hotsDeals =  require('./assets/hotsDeals.avif');
import hotsDeals from  "././assets/hotsDeals.avif";
// const threesquare =  require('./assets/threesquare.avif');
import threesquare from  "././assets/threesquare.avif";

export default {
    singlebanner,
    hotsDeals,
    threesquare

};

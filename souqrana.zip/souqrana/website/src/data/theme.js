export default {
  name: "souqarenas",
  fullName: "Ecommere plateform",
  author: {
    name: "souqarenas",
    profile_url: "https://wwww.souqarenas.com",
  },
  contacts: {
    address: "souqarenas Pvt. Ltd.",
    email: "support@souqarenas.com",
    phone: "+91 9237857155",
  },
};

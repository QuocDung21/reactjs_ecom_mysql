export default [
  {
    title: "Electronics",
    url: "/shop/catalog/electronics",
  },
  {
    title: "Smart Phones",
    url: "/shop/catalog/mobile-phone",
  },
  {
    title: "Watch",
    url: "/shop/catalog/watch",
  },
  {
    title: "Gaming",
    url: "/shop/catalog/gaming",
  },
];

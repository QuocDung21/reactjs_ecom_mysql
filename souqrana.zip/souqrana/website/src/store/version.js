const version = 2;

export default version;

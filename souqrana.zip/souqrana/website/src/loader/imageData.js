import LoaderGif from "./imageIcons/loader.gif";

const Images = {
  LoaderGif: LoaderGif,
};

export { Images };
export default Images;

export const constantText = {
  zone_msg_text: "Please select a Zone/State to assign",
};
